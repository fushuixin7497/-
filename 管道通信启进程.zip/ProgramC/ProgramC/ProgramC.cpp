#include <stdio.h>

int main()
{
	printf("Hikvision2018.05.17 14:21\n");
	return 0;
}
