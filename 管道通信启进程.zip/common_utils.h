#ifndef __ops_mgr_tinyutils_h__
#define __ops_mgr_tinyutils_h__

#if (defined _WIN32 || defined _WIN64)
#include <WinSock2.h>
#include <Windows.h>
#else
#include<cstdio>
#include<unistd.h>
#include<iostream>
#include<sys/wait.h>
#include<memory.h>
#endif
#include <string>
#include <cstdlib>
#include <map>
#include<vector>
#if (defined _WIN32 || defined _WIN64)
class CCodeConvert
{
public:
	// @fn 
	// @brief 
	// @param in ���ַ��洢��UNICODE��������
	// @return ���ַ���UTF8��������
	static std::string WUNICODE_to_UTF8(const wchar_t * wstrUNICODE)
	{
		int iLenInCharacters = WideCharToMultiByte(CP_UTF8, 0, wstrUNICODE, -1, NULL, 0, NULL, NULL);
		std::string strMultiString;
		strMultiString.resize(iLenInCharacters - 1); // ��ȥ '\0' ��β
		WideCharToMultiByte(CP_UTF8, 0, wstrUNICODE, -1, (char *)strMultiString.data(), strMultiString.size(), NULL, NULL);
		return strMultiString;
	};

	// @fn 
	// @brief 
	// @param in ���ַ���UTF8����
	// @return	���ַ��洢��UNICODE����
	static std::wstring UTF8_to_WUNICODE(const char * strUTF8)
	{
		int iLenInCharacters = MultiByteToWideChar(CP_UTF8, 0, strUTF8, -1, NULL, 0);
		std::wstring wstrWideString;
		wstrWideString.resize(iLenInCharacters - 1); // ��ȥ '\0' ��β
		MultiByteToWideChar(CP_UTF8, 0, strUTF8, -1, (wchar_t *)wstrWideString.data(), wstrWideString.size());
		return wstrWideString;
	};

	// @fn 
	// @brief 
	// @param in ���ַ��洢��UNICODE��������
	// @return ���ַ���ACP��������
	static std::string WUNICODE_to_ACP(const wchar_t * wstrUNICODE)
	{
		int iLenInCharacters = WideCharToMultiByte(CP_ACP, 0, wstrUNICODE, -1, NULL, 0, NULL, NULL);
		std::string strMultiString;
		strMultiString.resize(iLenInCharacters - 1); // ��ȥ '\0' ��β
		WideCharToMultiByte(CP_ACP, 0, wstrUNICODE, -1, (char *)strMultiString.data(), strMultiString.size(), NULL, NULL);
		return strMultiString;
	};

	// @fn 
	// @brief 
	// @param in ���ַ���ACP����
	// @return	���ַ��洢��UNICODE����
	static std::wstring ACP_to_WUNICODE(const char * strACP)
	{
		int iLenInCharacters = MultiByteToWideChar(CP_ACP, 0, strACP, -1, NULL, 0);
		std::wstring wstrWideString;
		wstrWideString.resize(iLenInCharacters - 1); // ��ȥ '\0' ��β
		MultiByteToWideChar(CP_ACP, 0, strACP, -1, (wchar_t *)wstrWideString.data(), wstrWideString.size());
		return wstrWideString;
	};
	
	static std::string ACP_to_UTF8(const char * strACP)
	{
		std::wstring wstrUNICODE =  ACP_to_WUNICODE(strACP);
		return WUNICODE_to_UTF8(wstrUNICODE.c_str());
	};

	static std::string UTF8_to_ACP(const char * strUTF8)
	{
		std::wstring wstrUNICODE =  UTF8_to_WUNICODE(strUTF8);
		return WUNICODE_to_ACP(wstrUNICODE.c_str());
	};

	
	static void SetLocalForStdCPP()
	{
		setlocale(LC_ALL,"");
	};
};
#else
class CCodeConvert
{
public:
	// @fn 
	// @brief 
	// @param in ���ַ��洢��UNICODE��������
	// @return ���ַ���UTF8��������
	static std::string WUNICODE_to_UTF8(const wchar_t * wstrUNICODE)
	{
		std::wstring w_str(wstrUNICODE);
		if(w_str.empty())
		{
			return "";
		}

		unsigned len = w_str.size() * 4 +1;
		setlocale(LC_CTYPE, "en_US.UTF-8");
		char *p = new char[len];
		wcstombs(p, w_str.c_str(), len);
		std::string str(p);
		delete[] p;
		return str;
	};

	// @fn 
	// @brief 
	// @param in ���ַ���UTF8����
	// @return	���ַ��洢��UNICODE����
	static std::wstring UTF8_to_WUNICODE(const char * strUTF8)
	{
		std::string str(strUTF8);
		if(str.empty())
		{
			return L"";
		}
		
		unsigned len = str.size() + 1;
		setlocale(LC_CTYPE,"en_US.UTF-8");
		wchar_t *p = new wchar_t[len];
		mbstowcs(p, str.c_str(), len);
		std::wstring w_str(p);
		delete[] p;
		return w_str;
	};

	// @fn 
	// @brief 
	// @param in ���ַ��洢��UNICODE��������
	// @return ���ַ���ACP��������
	static std::string WUNICODE_to_ACP(const wchar_t * wstrUNICODE)
	{
		std::wstring w_str(wstrUNICODE);
		if(w_str.empty())
		{
			return "";
		}

		unsigned len = w_str.size() * 4 +1;
		setlocale(LC_CTYPE, "en_US.UTF-8");
		char *p = new char[len];
		wcstombs(p, w_str.c_str(), len);
		std::string str(p);
		delete[] p;
		return str;
	};

	// @fn 
	// @brief 
	// @param in ���ַ���ACP����
	// @return	���ַ��洢��UNICODE����
	static std::wstring ACP_to_WUNICODE(const char * strACP)
	{
		std::string str(strACP);
		if(str.empty())
		{
			return L"";
		}
		
		unsigned len = str.size() + 1;
		setlocale(LC_CTYPE,"en_US.UTF-8");
		wchar_t *p = new wchar_t[len];
		mbstowcs(p, str.c_str(), len);
		std::wstring w_str(p);
		delete[] p;
		return w_str;
	};
	
	static std::string ACP_to_UTF8(const char * strACP)
	{
		std::wstring wstrUNICODE =  ACP_to_WUNICODE(strACP);
		return WUNICODE_to_UTF8(wstrUNICODE.c_str());
	};

	static std::string UTF8_to_ACP(const char * strUTF8)
	{
		std::wstring wstrUNICODE =  UTF8_to_WUNICODE(strUTF8);
		return WUNICODE_to_ACP(wstrUNICODE.c_str());
	};

	
	static void SetLocalForStdCPP()
	{
		setlocale(LC_ALL,"");
	};
};
#endif

class CMyTime
{
public:
	// @fn 
	// @brief ��ȡʱ���ַ��� 2017-08-16T08:00:00.123+08:00
	// @param 
	// @return	 
	static std::string GetCurrentTimeString()
	{
		std::string strTime;
		strTime.clear();
		time_t rawtime;
		struct tm * timeinfo;
		char buffer[80];
		time(&rawtime);
		timeinfo = localtime(&rawtime);
		//"yyyy-MM-ddThh:mm:ss:zzz"
		strftime(buffer, 80, "%Y-%m-%dT%H:%M:%S:222+08:00", timeinfo);
		strTime.append(buffer);
		return strTime;
	}
};

#if (defined _WIN32 || defined _WIN64)
class CExecProcess
{
public:
	static DWORD CreateIndependentProcessW(char const *strCmd)
	{
		//LOG_SETUP_DEBUG("[cmd]: %s", strCmd);
		std::string strCmdCopy("cmd.exe /c ");

		//strRunCMDLine.append("\"");           
		strCmdCopy.append("\"");      //cmd /c �Ĳ�����Ҫ�����Ű���
		strCmdCopy.append(strCmd);
		strCmdCopy.append("\"");

		std::wstring wstrCmdCopy = CCodeConvert::ACP_to_WUNICODE(strCmdCopy.c_str());

		STARTUPINFO si = {0} ;
		PROCESS_INFORMATION pi = {0};
		si.cb = sizeof(STARTUPINFO);
		si.dwFlags = STARTF_USESHOWWINDOW;
		si.wShowWindow = SW_HIDE;  
		int iRet = 0;
		BOOL bRet = CreateProcess(
			NULL,
			(LPWSTR) wstrCmdCopy.c_str(),
			NULL,
			NULL,
			FALSE,
			CREATE_NO_WINDOW,
			NULL,
			NULL,
			&si,
			&pi
			);
		if (bRet == FALSE)
		{
			DWORD iErr = GetLastError();
			return 0xFF + iErr;
		}
		CloseHandle(pi.hThread);      
		// �����ڵȴ��߳�ִ�����  
		// ���̱߳�����  
		WaitForSingleObject(pi.hProcess,INFINITE);  
		DWORD dwExitCode;  
		GetExitCodeProcess(pi.hProcess, &dwExitCode);  
		CloseHandle(pi.hProcess);  

		return dwExitCode;
	};
	static DWORD CreateIndependentProcessNoCmdWithInfoW(char const *strProcess, std::string &Feedback)
	{
		//LOG_SETUP_DEBUG("[cmd]: %s", strCmd);
		std::string strCmdCopy(strProcess);
		std::wstring wstrCmdCopy = CCodeConvert::ACP_to_WUNICODE(strCmdCopy.c_str());
		char buff[2048] = {0};	//�ܵ�������
		DWORD len;	//���ֽ�
		STARTUPINFO si;
		HANDLE read,write;	//�ܵ���д���
		SECURITY_ATTRIBUTES sa;

		sa.nLength = sizeof(sa);
		sa.bInheritHandle = TRUE;	//�ɼ̳�
		sa.lpSecurityDescriptor = NULL;
		//���������ܵ�
		if(!CreatePipe(&read,&write,&sa,2048))
		{
			//Ϊ�뷵���ж�ֵ��ͬ,�����������
			DWORD iErr = GetLastError();
			return 0xFF + iErr;
		}
		ZeroMemory(&si,sizeof(si));
		si.cb = sizeof(si);
		si.dwFlags = STARTF_USESTDHANDLES;	
		si.wShowWindow = SW_HIDE;
		si.hStdInput = read;
		si.hStdOutput = write;

		PROCESS_INFORMATION pi;
		int iRet = 0;
		BOOL bRet = CreateProcess(
			NULL,	
			(LPWSTR)wstrCmdCopy.c_str(),
			NULL,
			NULL,
			TRUE,
			CREATE_NO_WINDOW,
			NULL,
			NULL,
			&si,
			&pi);
		if (bRet == FALSE)
		{
			DWORD iErr = GetLastError();
			return 0xFF + iErr;
		}
		//�����ں˶����ڸ������в���ʹ��,��Ҫ��ʱ�ͷ�
		//CloseHandle(pi.hProcess);
		CloseHandle(pi.hThread);
		CloseHandle(write); 
		while(ReadFile(read,buff,2047,&len,NULL))
		{
			Feedback +=  buff;

			ZeroMemory(buff,2047);
		}
		//��ȡ��ܵ���Ϣ,���ڹر�read�ܵ��ں˶���
		CloseHandle(read);
		DWORD dwExitCode;  
		GetExitCodeProcess(pi.hProcess, &dwExitCode);  
		CloseHandle(pi.hProcess);
		return dwExitCode;
	};
	static DWORD CreateIndependentProcessNoCmdW(char const *strProcess)
	{
		//LOG_SETUP_DEBUG("[cmd]: %s", strCmd);
		std::string strCmdCopy(strProcess);
		std::wstring wstrCmdCopy = CCodeConvert::ACP_to_WUNICODE(strCmdCopy.c_str());
		STARTUPINFO si = {0} ;
		PROCESS_INFORMATION pi = {0};
		si.cb = sizeof(STARTUPINFO);
		si.dwFlags = STARTF_USESHOWWINDOW;
		si.wShowWindow = SW_HIDE;  
		int iRet = 0;
		BOOL bRet = CreateProcess(
			NULL,
			(LPWSTR) wstrCmdCopy.c_str(),
			NULL,
			NULL,
			FALSE,
			CREATE_NO_WINDOW,
			NULL,
			NULL,
			&si,
			&pi
			);
		if (bRet == FALSE)
		{
			DWORD iErr = GetLastError();
			return 0xFF + iErr;
		}
		CloseHandle(pi.hThread);      
		// �����ڵȴ��߳�ִ�����  
		// ���̱߳�����  
		WaitForSingleObject(pi.hProcess,INFINITE);  
		DWORD dwExitCode;  
		GetExitCodeProcess(pi.hProcess, &dwExitCode);  
		CloseHandle(pi.hProcess);  

		return dwExitCode;
	};

    static DWORD CreateIndependentProcessNoCmdWithEnvW(char const *strProcess, 
                                                       const std::map<std::string, std::string> &mapEnv)
    {
        //LOG_SETUP_DEBUG("[cmd]: %s", strCmd);
        std::string strCmdCopy(strProcess);
        std::wstring wstrCmdCopy = CCodeConvert::ACP_to_WUNICODE(strCmdCopy.c_str());

        for (std::map<std::string, std::string>::const_iterator it = mapEnv.begin();
            it != mapEnv.end(); ++it)
        {
            SetEnvironmentVariable(CCodeConvert::ACP_to_WUNICODE(it->first.c_str()).c_str(), CCodeConvert::ACP_to_WUNICODE(it->second.c_str()).c_str());
        }

        STARTUPINFO si = {0} ;
        PROCESS_INFORMATION pi = {0};
        si.cb = sizeof(STARTUPINFO);
        si.dwFlags = STARTF_USESHOWWINDOW;
        si.wShowWindow = SW_HIDE;  
        int iRet = 0;
        BOOL bRet = CreateProcess(
            NULL,
            (LPWSTR) wstrCmdCopy.c_str(),
            NULL,
            NULL,
            FALSE,
            CREATE_NO_WINDOW,
            NULL,
            NULL,
            &si,
            &pi
            );
        if (bRet == FALSE)
        {
            DWORD iErr = GetLastError();
            return 0xFF + iErr;
        }
        CloseHandle(pi.hThread);   

        for (std::map<std::string, std::string>::const_iterator it = mapEnv.begin();
            it != mapEnv.end(); ++it)
        {
            SetEnvironmentVariable(CCodeConvert::ACP_to_WUNICODE(it->first.c_str()).c_str(), L"");
        }
        // �����ڵȴ��߳�ִ�����  
        // ���̱߳�����  
        WaitForSingleObject(pi.hProcess,INFINITE);  
        DWORD dwExitCode;  
        GetExitCodeProcess(pi.hProcess, &dwExitCode);  
        CloseHandle(pi.hProcess);  

        return dwExitCode;
    };
};
#else
class CExecProcess
{
public:
	static int CreateIndependentProcessW(char const *strCmd)
	{
		int status;
		std::string command=strCmd;
		command += " 1>/dev/null 2>/dev/null";
		pid_t pid = fork(); 
		if(pid < 0)
		{
			return -1;	
		}
		else if(pid == 0)
		{
			int backCode = system(command.c_str());
			if(0 == backCode)
			{
				exit(0);
			}else
			{
				exit(1);
			}

		}
		//wait(&status);
		waitpid(pid, &status,0);
		return WEXITSTATUS(status);
	};
	static int CreateIndependentProcessNoCmdWithInfoW(char const *strProcess, std::string &Feedback)
	{
		int status;
		FILE * fp;
		char buffer[2048];
		fp = popen(strProcess,"r");
		if(NULL == fp)
	    {
            return -1;
	    }
		while((fgets(buffer, sizeof(buffer),fp)) != NULL)
		{
			Feedback +=  buffer;
			memset(buffer, 0, sizeof(buffer));
		}
		status = pclose(fp);
		if (-1 == status)  
        {  
           return -1;//pclose ʧ��
	    }
		else
		{
			if (WIFEXITED(status))
			{
				return WEXITSTATUS(status);
			}
			else
			{
				return -1;//�ӽ���ִ��ʧ��
			}
		}
		
	};
	static int CreateIndependentProcessNoCmdW(char const *strProcess)
	{
		int status;
		std::string command=strProcess;
		command += " 1>/dev/null 2>/dev/null";
		pid_t pid = fork(); 
		if(pid < 0)
		{
			return -1;	
		}
		else if(pid == 0)
		{
			int backCode = system(command.c_str());
			if(0 == backCode)
			{
				exit(0);
			}else
			{
				exit(1);
			}

		}
		wait(&status);
		return WEXITSTATUS(status);
	};

    static int CreateIndependentProcessNoCmdWithEnvW(char const *strProcess, 
                                                       const std::map<std::string, std::string> &mapEnv)
    {
        int status;
        std::string command=strProcess;
        command += " 1>/dev/null 2>/dev/null";
        
        for (std::map<std::string, std::string>::const_iterator it = mapEnv.begin();
            it != mapEnv.end(); ++it)
        {
            setenv(it->first.c_str(),it->second.c_str(),1);
        }

        pid_t pid = fork(); 
        if(pid < 0)
        {
            return -1;	
        }
        else if(pid == 0)
        {
            int backCode = system(command.c_str());
            if(0 == backCode)
            {
                exit(0);
            }else
            {
                exit(1);
            }

        }
        wait(&status);

        for (std::map<std::string, std::string>::const_iterator it = mapEnv.begin();
            it != mapEnv.end(); ++it)
        {
            setenv(it->first.c_str(), "",1);
        }

        return WEXITSTATUS(status);
    };
	
	static void str_replace(std::string & str, const std::string & strsrc, const std::string &strdst)
	{
		std::string::size_type pos = 0;//λ�� 
		std::string::size_type srclen = strsrc.size();//Ҫ�滻���ַ�����С 
		std::string::size_type dstlen = strdst.size();//Ŀ���ַ�����С 
		while ((pos = str.find(strsrc, pos)) != std::string::npos)
		{
			str.replace(pos, srclen, strdst);
			pos += dstlen;
		}
	};
};
#endif

class CTool
{
public:
	CTool() {};
	~CTool() {};
	static void Tokenize(const std::string& src, std::string delimit, std::vector<std::string>& v)
	{
		if (src.empty() || delimit.empty())
		{
			return;
		}

		std::string::size_type lastPos = 0, thisPos = std::string::npos;
		while (std::string::npos != (thisPos = src.find(delimit, lastPos)))
		{
			if (lastPos == thisPos)
			{
				v.push_back("");
			}
			else
			{
				v.push_back(src.substr(lastPos, thisPos - lastPos));
			}
			lastPos = thisPos + delimit.size();
		}

		if (lastPos != src.size())
		{
			v.push_back(src.substr(lastPos));
		}
	}

	static void str_replace(std::string & str, const std::string & strsrc, const std::string &strdst)
	{
		std::string::size_type pos = 0;//λ�� 
		std::string::size_type srclen = strsrc.size();//Ҫ�滻���ַ�����С 
		std::string::size_type dstlen = strdst.size();//Ŀ���ַ�����С 
		while ((pos = str.find(strsrc, pos)) != std::string::npos)
		{
			str.replace(pos, srclen, strdst);
			pos += dstlen;
		}
	}

private:

};

#endif
